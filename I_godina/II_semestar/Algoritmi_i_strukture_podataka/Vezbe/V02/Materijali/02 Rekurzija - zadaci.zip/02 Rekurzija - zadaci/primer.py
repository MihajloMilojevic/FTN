"""
Program izračunava sumu liste rekurzivnim putem.
"""

import time


def recursive_sum_linear(seq, n):
    """
    Funkcija izračunava sumu liste od n elemenata upotrebom linearne rekurzije.

    Argumenti:
    - `seq`: lista čija suma se izračunava
    - `n`: broj preostalih elemenata za sumiranje
    """

    # bazni slučaj
    if n == 0:
        return 0
    else:
        # izračunava se zbir poslednjeg i svih ostalih elemenata
        return seq[n-1] + recursive_sum_linear(seq, n-1)


def recursive_sum_binary(seq):
    """
    Funkcija izračunava sumu liste od n elemenata upotrebom binarne rekurzije.

    Argumenti:
    - `seq`: lista čija suma se izračunava
    """

    # bazni slučaj
    if len(seq) == 1:
        return seq[0]
    else:
        # izračunava se zbir poslednjeg i svih ostalih elemenata
        return recursive_sum_binary(seq[:len(seq)//2]) + recursive_sum_binary(seq[len(seq)//2:])


def recursive_sum_linear_without_slice(seq, start, end):
    """
    Funkcija izračunava sumu liste od n elemenata upotrebom binarne rekurzije.

    Argumenti:
    - `seq`: lista čija suma se izračunava
    """

    if start > end:
        return 0
    elif start == end:
        return seq[start]
    else:
        return seq[start] + recursive_sum_linear_without_slice(seq, start+1, end)


def recursive_sum_binary_without_slice(seq, start, end):
    """
    Funkcija izračunava sumu liste od n elemenata upotrebom binarne rekurzije.

    Argumenti:
    - `seq`: lista čija suma se izračunava
    """

    if start > end:
        return 0
    elif start == end:
        return seq[start]
    else:
        middle = start + int((end-start)/2)
        return recursive_sum_binary_without_slice(seq, start, middle) + \
            recursive_sum_binary_without_slice(seq, middle+1, end)


def iterative_sum(seq):
    sum = 0
    for element in seq:
        sum += element

    return sum


if __name__ == '__main__':
    a = [x for x in range(1, 998)]

    print("------Linearna rekurzija------")
    start = time.time()
    recursive_sum_linear = recursive_sum_linear(a, len(a))
    end = time.time() - start
    print("Rezultat: %d" % recursive_sum_linear)
    print("Vreme: " + str(end))

    print("------Binarna rekurzija------")
    start = time.time()
    recursive_sum_binary = recursive_sum_binary(a)
    end = time.time() - start
    print("Rezultat: %d" % recursive_sum_binary)
    print("Vreme: " + str(end))

    print("------Linearna rekurzija bez sliceing-a------")
    start = time.time()
    recursive_sum_linear_without_slice = recursive_sum_linear_without_slice(a, 0, len(a)-1)
    end = time.time() - start
    print("Rezultat: %d" % recursive_sum_linear_without_slice)
    print("Vreme: " + str(end))

    print("------Binarna rekurzija bez sliceing-a------")
    start = time.time()
    recursive_sum_binary_without_slice = recursive_sum_binary_without_slice(a, 0, len(a)-1)
    end = time.time() - start
    print("Rezultat: %d" % recursive_sum_binary_without_slice)
    print("Vreme: " + str(end))


