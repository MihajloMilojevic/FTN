let photosURL = "https://jsonplaceholder.typicode.com/photos";

let currentImg;
let overlayDiv = document.getElementById("overlay");
