function pushToStack(){
    let ul=document.getElementsByTagName("ul")[0];
    let firstLi=document.getElementsByTagName("li")[0];

    let newLi=document.createElement("li");
    let text=document.createTextNode("New li with some text");
    newLi.appendChild(text);
    
    ul.insertBefore(newLi, firstLi);
}