import java.util.Scanner;

public class App {
    static Scanner scanner = new Scanner(System.in);
    static int brojStudenata = 0;
    static String[][] studenti;
    static int[][] bodovi;

    public static void main(String[] args) throws Exception {
        System.out.println("Aplikacija za evidenciju studenata i bodova");
        boolean exit = false;
        studenti = new String[50][3];
        bodovi = new int[50][2];

        while (exit != true) {
            System.out.println("-----------------------");
            System.out.println("----- Glavni meni -----");
            System.out.println("0. Izlazak iz aplikacije");
            System.out.println("1. Dodavanje studenta");
            System.out.println("2. Dodavanje bodova");
            System.out.println("3. prikazi bodove svih studenata");
            System.out.println("4. prikazi bodove najgoreg studenta");

            int choice = readInt("Izaberi opciju: ");
            // treba dopuniti kod da bi se ostale metode ispravno pozivale
            switch (choice) {
	            case 0:
	                System.out.println("Izlazak iz aplikacije");
	                exit = true;
	                break;
	            case 1:
	            	dodajStudenta();
                    break;
	            case 2:
	            	dodajBodove();
                    break;
	            case 3:
	            	prikaziSveBodove();
                    break;
	            case 4:
	            	prikaziNajgoreg();
                    break;
                default:
                    System.out.println("Pogresan unos, izaberi ponovo.");
            }
        }
    }

    static int readInt(String prompt) {
        System.out.print(prompt);
        int res = scanner.nextInt();
        scanner.nextLine();
        return res;
    }

    static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }

    /**
     * Metoda dodaje studenta u listu studenata.
     */
    static void dodajStudenta() {
        String input = readString("unesi podatke o studentu u formatu [indeks;ime;prezime]: ");
        String[] studentData = input.split(";");
        studenti[brojStudenata] = studentData;
        System.out.println("Uspesno dodat student:" + studentData[1] + " " + studentData[2]);
        brojStudenata++;
    }
    
    /**
     * Metoda pronalazi studenta sa datim indexom
     * @param index studneta
     * @return index u matrici ako postoji, -1 ako ne
     */
    static int nadjiStudenta(String index) {
    	for(int i = 0; i < brojStudenata; i++) {
    		if(studenti[i][0].equals(index))
    			return i;
    	}
    	return -1;
    }

    /**
     * Metoda dodaje bodove u listu bodova.
     */
    static void dodajBodove() {
        String index = readString("unesi indeks studenta: ");
        int i = nadjiStudenta(index);
        if(i < 0) {
        	System.out.printf("Student sa indeksom %s nije pronadjen\n", index);
        	return;
        }
        String unos = readString("Unesi bodove za studenta u formatu [bodovi1 bodovi2]: ");
        String bodoviStr[] = unos.split(" +");
        bodovi[i][0] = Integer.parseInt(bodoviStr[0]);
        bodovi[i][1] = Integer.parseInt(bodoviStr[1]);
        System.out.println("Uspesno uneti bodovi za studenta " + index);
    }

    /**
     * Metoda prikazuje bodove svih studenata.
     */
    static void prikaziSveBodove() {
    	for(int i = 0; i < brojStudenata; i++) {
    		System.out.printf("|%s|%d|%d|\n", studenti[i][0], bodovi[i][0], bodovi[i][1]);
    	}
    }

    /**
     * Metoda prikazuje studenta koji je osvojio najmanje bodova
     */
    static void prikaziNajgoreg() {
    	if(brojStudenata == 0) {
    		System.out.println("Ne postoji najgori student.");
    		return;
    	}
    	int minZbir = bodovi[0][0] + bodovi[0][1];
    	int minIndex = 0;
    	for(int i = 1; i < brojStudenata; i++) {
    		int trZbir = bodovi[i][0] + bodovi[i][1];
    		if(trZbir < minZbir) {
    			minIndex = i;
    			minZbir = trZbir;
    		}
    	}
    	System.out.printf("Student %s %s ima najmanje osvojenih bodova %d\n", studenti[minIndex][1], studenti[minIndex][2], minZbir);
    }
}