import java.util.Scanner;

public class App {
    static Scanner scanner = new Scanner(System.in);
    static int brojStudenata = 0;
    static String[][] studenti;
    static int[][] bodovi;

    public static void main(String[] args) throws Exception {
        System.out.println("Aplikacija za evidenciju studenata i bodova");
        boolean exit = false;
        studenti = new String[50][3];
        bodovi = new int[50][2];

        while (exit != true) {
            System.out.println("-----------------------");
            System.out.println("----- Glavni meni -----");
            System.out.println("0. Izlazak iz aplikacije");
            System.out.println("1. Dodavanje studenta");
            System.out.println("2. Dodavanje bodova");
            System.out.println("3. prikazi bodove svih studenata");
            System.out.println("4. prikazi bodove najgoreg studenta");

            int choice = readInt("Izaberi opciju: ");
            // treba dopuniti kod da bi se ostale metode ispravno pozivale
            switch (choice) {
                case 0:
                    System.out.println("Izlazak iz aplikacije");
                    exit = true;
                    break;
                default:
                    System.out.println("Pogresan unos, izaberi ponovo.");
            }
        }
    }

    static int readInt(String prompt) {
        System.out.print(prompt);
        return scanner.nextInt();
    }

    static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.next();
    }

    /**
     * Metoda dodaje studenta u listu studenata.
     */
    static void dodajStudenta() {
        String input = readString("unesi podatke o studentu u formatu [indeks;ime;prezime]: ");
        String[] studentData = input.split(";");
        studenti[brojStudenata] = studentData;
        System.out.println("Uspesno dodat student:" + studentData[1] + " " + studentData[2]);
        brojStudenata++;
    }

    /**
     * Metoda dodaje bodove u listu bodova.
     */
    static void dodajBodove() { }

    /**
     * Metoda prikazuje bodove svih studenata.
     */
    static void prikaziSveBodove() { }

    /**
     * Metoda prikazuje studenta koji je osvojio najmanje bodova
     */
    static void prikaziNajgoreg() { }
}