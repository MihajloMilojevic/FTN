package creational.factory;

public abstract class Vozilo {
	public abstract void vozi();
}
