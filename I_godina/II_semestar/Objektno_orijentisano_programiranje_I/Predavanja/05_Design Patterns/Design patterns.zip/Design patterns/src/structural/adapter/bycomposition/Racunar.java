package structural.adapter.bycomposition;

public class Racunar {
	USBTastatura tastatura;
	
	public void testTastature() {
		System.out.println(tastatura.vratiTaster());
	}
}
