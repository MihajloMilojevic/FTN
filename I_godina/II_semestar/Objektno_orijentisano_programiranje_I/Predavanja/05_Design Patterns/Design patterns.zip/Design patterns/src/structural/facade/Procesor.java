package structural.facade;

class Procesor {
	public void skociNa(int adresa, Memorija memorija) {
		System.out.println("PROC: izvrsavam program na adresi: " + adresa);
	}
}
