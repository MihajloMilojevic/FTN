package behavioral.interpreter.booleaninterpreter;

public interface BooleanExpression {
	public boolean evaluate(Context ctx);
}
