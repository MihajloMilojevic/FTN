package structural.facade;

class Memorija {
	public void ucitajBootSektor(byte boot[]) {
		System.out.println("MEM: ucitao boot sektor sa diska");
	}
}
