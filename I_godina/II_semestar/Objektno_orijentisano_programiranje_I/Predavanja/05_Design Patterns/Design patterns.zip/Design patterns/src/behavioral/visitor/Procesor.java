package behavioral.visitor;

public class Procesor extends HardverskiElement {

	@Override
	public double potrosnja() {
		return 100;
	}

	@Override
	public double cena() {
		return 100;
	}

}
