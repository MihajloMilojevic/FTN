package behavioral.mediator;

public interface Mediator {
	public void sendMessageToColleagues(String message, String senderName);
}
