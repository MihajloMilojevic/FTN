package structural.proxy;

public interface ServerI {
	public boolean login(String username, String password) throws Exception;
}
