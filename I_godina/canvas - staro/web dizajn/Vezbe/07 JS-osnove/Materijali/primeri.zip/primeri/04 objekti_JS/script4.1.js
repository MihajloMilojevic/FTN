let student1=new Object()
student1.ime="Djole";
student1.prezime="Djole";

let student2={
  ime:"Luka",
  prezime:"Luka",
}