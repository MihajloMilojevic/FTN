//Porucje vazenja
    function f1()
    {
        var v=10;
    }
    //console.log(v)
    for (let i = 0; i < 3; i++) {
        console.log(i);
    }
    //console.log(i);

    {
        const c = 2;
        console.log(c);
    }
    //console.log(c);

//Ponovna dodela vrednosti 
    var v1 = 1;
    v1 = 30;
    console.log(v1)

    let i1 = 1;
    i1 = 30;
    console.log(i1);

    const c1 = 1;
    // c1 = 30; //Const ne može da menja vrednost
    console.log(c1);
    

//Ponovno deklarisanje promenljive 
    var v2 = 1;
    var v2 = 30;    
    console.log(v2);

    let i2 = 1;
    // let i2 = 30; //Ne može jer je već definisana u ovom bloku
    console.log(i2);

    const c2 = 1;
    // const c2 = 30; //Ne može jer ima konstantnu vrednost
    console.log(c2)