//OBJECT
let person1=new Object()
person1.ime="Pera";
person1.prezime="Peric";
person1.predstaviSe = function () {
  return this.ime + " " + this.prezime;
}
alert(person1.ime+ " "+ person1.prezime)

//JSON
let person2={
  ime:"Mika",
  prezime:"Mikic",
  predstaviSe: function(){
    alert("Ja sam student " + this.ime + " "+ this.prezime)
  }
}
alert(person2.ime+ " "+ person2.prezime)
console.log(person2.predstaviSe())

//POZIVOM KOSTRUKTORA
function Person(ime, prezime){
  this.ime=ime;
  this.prezime=prezime;
};

var person3=new Person("Pera", "Peric");
alert("Ime treceg korisnika je "+person3.ime)

