console.log("Hi, from script1!");
