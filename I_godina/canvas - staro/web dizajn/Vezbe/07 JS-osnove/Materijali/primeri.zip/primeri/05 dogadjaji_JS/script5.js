function f2(a1){
    alert(a1)
}