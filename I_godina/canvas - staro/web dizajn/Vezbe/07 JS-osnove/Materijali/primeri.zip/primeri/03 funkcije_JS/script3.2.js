function changeProm(n) {
    n=643
}

var prom=5
console.log("Vrednost pre pozivanja funkcije "+prom);
changeProm(prom);
console.log("Vrednost nakon pozivanja funkcije "+prom);



//prosledjivanje objekta funkciji
    console.log("PROSLEDJIVANJE OBJEKTA FUNKCIJI")
    function changeCarFunc(carObject) {
        carObject.make = 'Toyota';
    }

    var myCar = {
        make: 'Honda',
        model: 'Accord',
        year: 1998,
    };

    console.log("Vrednost pre pozivanja funkcije "+ myCar.make);
    changeCarFunc(myCar);
    console.log("Vrednost nakon pozivanja funkcije "+myCar.make);


//prosledjivanje niza funkciji
    console.log("PROSLEDJIVANJE NIZA FUNKCIJI")
    function changeArrayFunc(theArr) {
        theArr[0] = 30;
    }
    
    const arr = [45,12,34,546];
    console.log(arr[0]); 
    changeArrayFunc(arr);
    console.log(arr[0]); 