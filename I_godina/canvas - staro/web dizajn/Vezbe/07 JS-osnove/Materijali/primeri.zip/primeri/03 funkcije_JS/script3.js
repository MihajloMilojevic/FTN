function myFunction(p1, p2) {
    return p1 * p2;
  }
document.getElementById("demo").innerHTML = myFunction(4, 3);