package demo;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		Student s1 = new Student("Mika Peric", "sv 11-2022" );

		Student s2 = new Student("Sima Mikic", "sv 12-2022");
		
		Student[] studenti = {s1, s2};
		for (Student s: studenti) {
			System.out.println(s);
		}
		
		
		ArrayList<Student> studentiLista = new ArrayList<>();
		studentiLista.add(s1);
		studentiLista.add(s2);
		for (Student s: studentiLista) {
			System.out.println(s);
		}
		System.out.println(Student.brojac);
		
		Student s3 = new Student();
		System.out.println(Student.brojac);

	}

}
