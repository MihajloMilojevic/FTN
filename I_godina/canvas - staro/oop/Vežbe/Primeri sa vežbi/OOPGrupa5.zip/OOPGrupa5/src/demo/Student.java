package demo;

public class Student {
	
	private String imeIPrezime;
	private String indeks;
	public static int brojac;
	
	public String getImeIPrezime() {
		return imeIPrezime;
	}

	public void setImeIPrezime(String imeIPrezime) {
		this.imeIPrezime = imeIPrezime;
	}

	public String getIndeks() {
		return indeks;
	}

	public void setIndeks(String indeks) {
		this.indeks = indeks;
	}
	
	Student() {
		brojac++;
		
	}

	Student(String imeIPrezime, String indeks) {
		this();
		this.imeIPrezime = imeIPrezime;
		this.indeks = indeks;
	}
	
	void ispisi() {
		System.out.println(this);
	}
	
	public String toString() {
		return "Student " + this.indeks + " " + this.imeIPrezime;
	}

}
