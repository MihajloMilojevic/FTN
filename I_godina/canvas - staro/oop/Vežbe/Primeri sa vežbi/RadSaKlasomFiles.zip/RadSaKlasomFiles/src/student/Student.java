package student;

public class Student {
	
	private String imeIPrezime;
	private String indeks;
	
	
	
	public Student(String imeIPrezime, String indeks) {
		this.imeIPrezime = imeIPrezime;
		this.indeks = indeks;
	}



	public String getImeIPrezime() {
		return imeIPrezime;
	}



	public void setImeIPrezime(String imeIPrezime) {
		this.imeIPrezime = imeIPrezime;
	}



	public String getIndeks() {
		return indeks;
	}



	public void setIndeks(String indeks) {
		this.indeks = indeks;
	}



	public String toString() {
		return "Student " + this.indeks + " " + this.imeIPrezime;
	}

}
