package student;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
//import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class Test {
	
	public static void load(String path) {
		try {
			List<String> lines  = Files.readAllLines(Paths.get(path));
			for (String line: lines) {
				String[] data = line.split(";");
				System.out.println("Ime: " + data[0] + ", prezime: " + data[1]);
			}
		} catch (IOException ioE) {
			System.out.println("Greska pri ucitavanju.");
		} catch (ArrayIndexOutOfBoundsException arrEx) {
			System.out.println("Fale podaci u fajlu.");
		} catch (Exception e) {
			System.out.println("Nesto nije u redu");
		}
		
	}
	
	public static void save(String path, ArrayList<String> data) {
		try {
			Files.write(Paths.get(path), data);
			//Files.write(Paths.get(path), data, StandardOpenOption.APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	public static void main(String[] args) {
		
		String path = "korisnici.txt";
		
		load(path);
		
		
		ArrayList<String> lista = new ArrayList<>();
		lista.add("Jovan;Jovanovic");
		lista.add("Sima;Simic");
		
		save(path, lista);
		
	} 

}
