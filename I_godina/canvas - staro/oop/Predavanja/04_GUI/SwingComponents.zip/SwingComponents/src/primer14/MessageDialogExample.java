package primer14;

import javax.swing.JOptionPane;

class MessageDialogExample {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "First message");
	}
}
