# sorts.py
# Implementacije selection i merge sort algoritama

def selSort(lst):
    n = len(lst)
    for bottom in range(n-1):
        mp = bottom
        for i in range(bottom+1,n):
            if lst[i] < lst[mp]:
                mp = i
        lst[bottom], lst[mp] = lst[mp], lst[bottom]


def merge(lst1, lst2, lst3):
    # spaja sortirane liste lst1 i lst2 u lst3
    # indeksi prate tekuci polozaj u svakoj listi
    i1 = i2 = i3 = 0
    n1, n2 = len(lst1), len(lst2)

    # dok obe podliste nisu prazne
    while i1 < n1 and i2 < n2:
        if lst1[i1] < lst2[i2]:     # kopiraj iz lst1
            lst3[i3] = lst1[i1]     
            i1 = i1 + 1
        else:                       # kopiraj iz list2
            lst3[i3] = lst2[i2]     
            i2 = i2 + 1
        i3 = i3 + 1                 # dodat element u lst3

    # Ovde je lst1 ili lst2 orazna, Jedna od naredne dve
    # petlje ce se preskociti, a druga izvrsiti.
    
    # iskopiraj preostale elemente (ako ih ima) iz lst1
    while i1 < len(lst1):
        lst3[i3] = lst1[i1]
        i1 = i1 + 1
        i3 = i3 + 1
    # iskopiraj preostale elemente (ako ih ima) iz lst2
    while i2 < len(lst2):
        lst3[i3] = lst2[i2]
        i2 = i2 + 1
        i3 = i3 + 1


def mergeSort(lst):
    # Sortira lst u rastucem redosledu
    n = len(lst)
    # Ne radi nista ako lst ima 0 ili 1 element
    if n > 1:
        # podeli na dve podliste
        m = n // 2
        lst1, lst2 = lst[:m], lst[m:]
        # sortiraj podliste
        mergeSort(lst1)
        mergeSort(lst2)
        # spoj sortirane podliste
        merge(lst1, lst2, lst)


## Funkcije za merenje vremena sortiranja
        
## Primer:
## >>> from sorts import *
## >>> timingCurve(mergeSort, 1000, 2000, 5000, 5)
## Duzina liste:  1000
## 0
## 1
## 2
## 3
## 4
## avg = 0.2
## Duzina liste:  3000
## 0
## 1
## 2
## 3
## 4
## avg = 0.8
## [0.234578800201, 0.765318417549]

import random, time


def genList(n):
    # vraca listu od n slucajnih float-ova
    xs = []
    for i in range(n):
        xs.append(random.random())
    return xs


def timeSort(sortFn, n):
    # vraca vreme potrebno za sortiranje liste od n elemenata
    # koriscenjem funkcije sortFn
    xs = genList(n)
    t1 = time.time()
    sortFn(xs)
    t2 = time.time()
    return t2 - t1


def timingCurve(sortFn, start, inc, stop, trials):
    # Vraca listu prosecnih vremena potrebnih za sortiranje lista duzine
    # start, start+inc, start+2*inc, ..., stop.
    times = []
    for n in range(start, stop, inc):
        print("Duzina liste: ", n)
        sum = 0.0
        for i in range(trials):
            print(i)
            sum = sum + timeSort(sortFn,n)
        avg = sum / trials
        print("avg = {0:0.1f}".format(avg))
        times.append(avg)
    return times
