# hanoi.py
# Rekurzivno resavanje problema hanojskih kula

def moveTower(n, source, dest, temp):
    if n == 1:
        print("Premesti sa", source, "na", dest)
    else:
        moveTower(n-1, source, temp, dest)
        moveTower(1, source, dest, temp)
        moveTower(n-1, temp, dest, source)


def hanoi(n):
    moveTower(n, "A", "C", "B")


def main():
    print("Hanojske kule")
    n = eval(input("Koliko ima diskova? "))
    moveTower(n, "A", "C", "B")


if __name__ == '__main__': 
    main()

        
