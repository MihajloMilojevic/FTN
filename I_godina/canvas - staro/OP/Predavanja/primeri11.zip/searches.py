# searches.py
# Linearna i binarna pretraga

def linSearch(x, nums):
    for i in range(len(nums)):
        if nums[i] == x:       # pronadjen, vrati njegov indeks
            return i
    return -1                  # prosli celu listu, nismo pronasli


def binSearch(x, nums):
    low = 0
    high = len(nums)-1
    while low <= high:          # jos ima za pretragu
        mid = (low + high)//2   # polozaj srednjeg elementa
        item = nums[mid]
        if x == item :          # nasli smo trazeni element
            return mid
        elif x < item:          # x je u donjoj polovini
            high = mid - 1      #     premesti gornji limit
        else:                   # x je u gornjoj polovini
            low = mid + 1       #     premesti donji limit
    return -1                   # nema vise elemenata za pretragu, nismo nasli x


def recBinSearch(x, nums, low, high):
    if low > high:                        # nema vise elemenata, vrati -1
        return -1
    mid = (low + high) // 2
    item = nums[mid]
    if item == x:                         # nasli smo x
        return mid
    elif x < item:                        # trazi u donjoj polovini
        return recBinSearch(x, nums, low, mid-1)
    else:                                 # trazi u gornjoj polovini
        return recBinSearch(x, nums, mid+1, high)


def rbinSearch(x, nums):
    return recBinSearch(x, nums, 0, len(nums)-1)


import time, random

# Funkcija za testiranje. Mozemo je koristiti za merenje vremena
#    razlicitih postupaka za pretragu. Primer upotrebe:
#       >>> from searches import *
#       >>> avgTime(binSearch, 5000, 10)
#    Ispisace prosecno vreme potrebno za pronalazenje elementa u listi
#    od 5000 integera. Prosek se racuna za 10 pokusaja.

def avgTime(search, n, trials):
    # Napravi sortiranu listu duzine n
    l1 = list(range(n))
    print("Lista je formirana")

    # pokreni vise pretraga i izracunaj prosecno vreme
    sum = 0.0
    for i in range(trials):
        print(i+1,)                    # prikazi napredak
        target = random.randint(0,n)
        # procitaj sistemsko vreme pre pretrage
        t0 = time.time()
        pos = search(target, l1)
        # procitaj sistemsko vreme posle pretrage
        t1 = time.time()
        # dodaj izmereno vreme na sumu
        sum = sum + (t1-t0)
    print("\nprosek:", sum/trials)
    
