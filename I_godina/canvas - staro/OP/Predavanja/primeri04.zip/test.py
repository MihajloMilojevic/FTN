x = "A"
for x in "BCDE":
    print(x)
print(x)