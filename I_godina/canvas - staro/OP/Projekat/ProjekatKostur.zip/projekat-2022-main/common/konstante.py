ULOGA_KORISNIK = "korisnik"
ULOGA_PRODAVAC = "prodavac"
ULOGA_ADMIN = "admin"