from database import Database
from database.models.user import User

db = Database()
user: User = None
