# rball.py
from random import random


def main():
    printIntro()
    probA, probB, n = getInputs()
    winsA, winsB = simNGames(n, probA, probB)
    printSummary(winsA, winsB)


def printIntro():
    print("Ovaj program simulira racquetball partije izmedju igraca")
    print('zvanih "A" i "B".  Sposobnost svakog igraca je odredjena')
    print("verovatnocom (broj izmedju 0 i 1) da igrac osvoji poen")
    print("na svoj servis. Igrac A uvek servira prvi.\n")


def getInputs():
    a = eval(input("Verovatnoca da A osvoji poen na servis >> "))
    b = eval(input("Verovatnoca da B osvoji poen na servis >> "))
    n = eval(input("Broj partija za simulaciju >> "))
    return a, b, n


def simNGames(n, probA, probB):
    # simulira n racquetball partija izmedju igraca A i B
    # vraca broj pobeda A, broj pobeda B
    winsA = winsB = 0
    for i in range(n):
        scoreA, scoreB = simOneGame(probA, probB)
        if scoreA > scoreB:
            winsA = winsA + 1
        else:
            winsB = winsB + 1
    return winsA, winsB


def simOneGame(probA, probB):
    # Simulira jednu partiju gde su mogucnosti igraca
    # predstavljene verovatnocom osvajanja poena na svoj servis
    # Vraca sekvencu (broj poena A, broj poena B)
    serving = "A"
    scoreA = 0
    scoreB = 0
    while not gameOver(scoreA, scoreB):
        if serving == "A":
            if random() < probA:
                scoreA = scoreA + 1
            else:
                serving = "B"
        else:
            if random() < probB:
                scoreB = scoreB + 1
            else:
                serving = "A"
    return scoreA, scoreB


def gameOver(a, b):
    # a i b su tekuci broj poena u partiji
    # Vraca True ako je igra zavrsena
    return a == 15 or b == 15


def printSummary(winsA, winsB):
    # Ispisuje rezime odigranih partija
    n = winsA + winsB
    print("\nSimulirano partija:", n)
    print("Pobeda A: {0} ({1:0.1%})".format(winsA, float(winsA)/n))
    print("Pobeda B: {0} ({1:0.1%})".format(winsB, float(winsB)/n))


if __name__ == '__main__': 
    main()
