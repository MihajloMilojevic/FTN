# average7.py

def main():
    fileName = raw_input("Ime fajla sa brojevima? ")
    infile = open(fileName,'r')
    sum = 0.0
    count = 0
    line = infile.readline()
    while line != "":
        # update sum and count for values in line
        for xStr in line.split(","):
            sum = sum + eval(xStr)
            count = count + 1
        line = infile.readline()
    print "\nProsek je", sum / count

main()
