# average2.py

def main():
    sum = 0.0
    count = 0
    moredata = "da"
    while moredata[0] == "d":
        x = eval(raw_input("Unesite broj >> "))
        sum = sum + x
        count = count + 1
        moredata = raw_input("Ima jos brojeva (da ili ne)? ")
    print "\nProsek je", sum / count

main()
