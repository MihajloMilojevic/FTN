# average4.py

def main():
    sum = 0.0
    count = 0
    xStr = raw_input("Unesite broj (<Enter> za kraj) >> ")
    while xStr != "":
        x = eval(xStr)
        sum = sum + x
        count = count + 1
        xStr = raw_input("Unesite broj (<Enter> za kraj) >> ")
    print "\nProsek je", sum / count

main()
