# average1.py

def main():
    n = eval(raw_input("Koliko ima brojeva? "))
    sum = 0.0
    for i in range(n):
        x = eval(raw_input("Unesite broj >> "))
        sum = sum + x
    print "\nProsek je", sum / n

main()
