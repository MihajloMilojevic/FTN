# wordfreq.py

def byFreq(pair):
    return pair[1]

def main():
    print "Analizira frekvenciju reci u fajlu"
    print "i ispisuje n najcescih reci.\n"

    # ucitaj reci iz fajla
    fname = raw_input("File to analyze: ")
    text = open(fname,'r').read()
    text = text.lower()
    for ch in '!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~':
        text = text.replace(ch, ' ')
    words = text.split()

    # napravi recnik sa frekvencijama reci
    counts = {}
    for w in words:
        counts[w] = counts.get(w,0) + 1

    # ispisi najfrekventnije reci
    n = eval(raw_input("Koliko najfrekventnijih reci? "))
    items = list(counts.items())
    items.sort()
    items.sort(key=byFreq, reverse=True)
    for i in range(n):
        word, count = items[i]
        print "{0:<15}{1:>5}".format(word, count)

if __name__ == '__main__':  
    main()
