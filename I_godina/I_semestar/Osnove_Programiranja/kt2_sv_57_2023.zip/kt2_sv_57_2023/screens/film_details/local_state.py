from database.models import Film


current_film: Film = None