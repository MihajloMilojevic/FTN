from Database import Database
from Database.Models.User import User

db = Database()
user: User = None
