import Database.Models as Models

projection_to_edit: Models.Projection = None