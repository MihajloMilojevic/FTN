import Database.Models as Models

sala_to_edit: Models.Hall = None