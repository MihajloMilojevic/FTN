def easter(year):
    if 1900 <= year <= 2099:
        a = year % 19
        b = year % 4
        c = year % 7
        d = (19*a + 24) % 30
        e = (2*b + 4*c + 6*d + 5) % 7

        date = 22 + d + e

        if year in [1954, 1981, 2049, 2076]:
            date -= 7

        if date <= 31:
            month = "Mart"
        elif date <= 61:
            date -= 31
            month = "April"
        else:
            date -= 61
            month = "Maj"

        return date, month

    #ako godina nije u predviđenom opsegu
    raise Exception("Godina nije u predviđenom opsegu")


if __name__ == '__main__':
    year = int(input("Unesite godinu:"))
    try:
        date, month = easter(year)
        print("Datum Uskrsa po gregorijanskom kalendaru je " + str(date) + ". " + month + " " + str(year) + ".")

    except Exception as e:
        print(e)

