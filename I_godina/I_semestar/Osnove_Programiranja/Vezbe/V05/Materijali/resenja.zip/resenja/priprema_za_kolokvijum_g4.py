usernames = []
actions = []
amounts = []

def load_data(path):
    file = open(path)
    lines = file.readlines()
    file.close()
    for line in lines:
        line = line.replace("\n", "")
        # line = "milan34 income 23000.0"
        parts = line.split(" ")
        current_name = parts[0]
        current_action = parts[1]
        current_amount = 0
        if current_action != "newaccount":
            current_amount = float(parts[2])

        usernames.append(current_name)
        actions.append(current_action)
        amounts.append(current_amount)

def user_balance(username):
    balance = 0

    for index in range(len(usernames)):
        current_name = usernames[index]
        if username == current_name:
            action = actions[index]
            if action == "income":
                balance += amounts[index]
            elif action == "withdrawal":
                balance -= amounts[index]

    return balance

def get_all_balances(path):
    file = open(path)
    lines = file.readlines()
    file.close()

    users = []
    balances = []

    for line in lines:
        line = line.replace("\n", "")
        parts = line.split(" ")
        username = parts[0]
        action = parts[1]
        if action == "newaccount":
            users.append(username)
            balances.append(0)
        else:
            position = None
            for index in range(len(users)):
                if users[index] == username:
                    position = index
                    break

            if position != None:
                if action == "income":
                    balances[position] += float(parts[2])
                elif action == "withdrawal":
                    balances[position] -= float(parts[2])

    return users, balances

def richest(path):
    users, balances = get_all_balances(path)
    max = balances[0]
    max_index = 0

    for index in range(len(users)):
        if max < balances[index]:
            max = balances[index]
            max_index = index

    return users[max_index]

def max_number_of_incomes(path):
    file = open(path)
    lines = file.readlines()
    file.close()

    users = []
    incomes = []

    for line in lines:
        line = line.replace("\n", "")
        parts = line.split(" ")
        username = parts[0]
        action = parts[1]
        if action == "newaccount":
            users.append(username)
            incomes.append(0)
        elif action == "income":
            position = None
            for index in range(len(users)):
                if users[index] == username:
                    position = index
                    break

            if position != None:
                incomes[position] += 1

    max = incomes[0]
    max_index = 0

    for index in range(len(users)):
        if max < incomes[index]:
            max = incomes[index]
            max_index = index

    return users[max_index]

def print_data(users, balances):
    print("{:10}{:10}".format("Users", "Balances"))
    print("="*20)
    for index in range(len(users)):
        user = users[index]
        balance = balances[index]
        print("{:10}{:10.2f}".format(user, balance))


def main():
    path = "../fajlovi/bank_log.txt"
    users, balances = get_all_balances(path)
    print_data(users, balances)

    print(richest(path))

if __name__ == '__main__':
    main()