# 4. Stanje na računu. Iz log fajla (bank_log.txt) čitati podatke o korisnicima.
# Podaci su dati u obliku:
#         ime_korisnika tip_akcije [iznos]
# gde je parametar iznos opcioni.
#
# Tipovi akcija su sledeći:
# newaccount - korisnik kreira nalog
# income     - priliv sredstava na korisnikov račun
# withdrawal - korisnik je podigao novac sa računa
#
# Zadaci:
# 	a) Za zadatog korisnika odrediti stanje na računu.
#         b) Pronaći korisnika koji ima najviše novca na računu
#         c) Pronaći korisnika sa najvećim brojem uplata
#         d) Pronaći korisnike čije je stanje na računu manje od unetog iznosa
#         e) Pronaći sve korisnike čije ime počinje zadatim/unetim stringom
# 	f) Kreirati izveštaj stanja na računu za sve postojeće korisnike.
#
# Pretpostaviti da su podaci validni.

users = []
actions = []
amounts = []

def balance(user):

    for i in range(len(users)):
        if user == users[i]:
            action = actions[i]
            if action == 'newaccount':
                balance = 0
            elif action == "income":
                amount = amounts[i]
                balance += amount
            elif action == "withdrawal":
                amount = amounts[i]
                balance -= amount

    return balance

def calculate_all_balances():

    usernames = []
    accounts = []

    for i in range(len(users)):
        username = users[i]

        found = False
        for index in range(len(usernames)):
            if usernames[index] == username:
                found = True
                break

        if not found:
            usernames.append(username)
            accounts.append(balance(username))

    return usernames, accounts

def richest():
    usernames, accounts = calculate_all_balances()

    max_amount = accounts[0]
    max_index = 0

    for i in range(1, len(usernames)):
        if max_amount < accounts[i]:
            max_amount = accounts[i]
            max_index = i

    return usernames[max_index], max_amount

def max_number_of_incomes():
    usernames = []
    number_of_incomes = []

    for i in range(len(users)):
        username = users[i]

        if actions[i] == "income":
            found = False
            for index in range(len(usernames)):
                if usernames[index] == username:
                    number_of_incomes[index] += 1
                    break

            if not found:
                usernames.append(username)
                number_of_incomes.append(1)

    max_number = number_of_incomes[0]
    max_index = 0

    for i in range(1, len(usernames)):
        if max_number < number_of_incomes[i]:
            max_number = number_of_incomes[i]
            max_index = i

    return usernames[max_index]

def less_than(amount):
    usernames, accounts = calculate_all_balances()

    less_than_list = []

    for i in range(len(usernames)):
        if accounts[i] < amount:
            less_than_list.append(usernames[i])

    return less_than_list
    
def load_data(path):
    file = open(path)
    lines = file.readlines()
    file.close()

    for line in lines:
        line = line.replace("\n", "")
        parts = line.split(" ")
        username = parts[0]
        users.append(username)
        action = parts[1]
        actions.append(parts[1])

        if action == "newaccount":
            amount = None
        else:
            amount = float(parts[2])

        amounts.append(amount)

def unique_users():
    usernames = []
    for i in range(len(users)):
        username = users[i]

        found = False
        for index in range(len(usernames)):
            if usernames[index] == username:
                found = True
                break

        if not found:
            usernames.append(username)

    return usernames

def begins_with(string):
    usernames = unique_users()
    string_len = len(string)
    result_list = []
    for username in usernames:
        if username[:string_len] == string:
        # može i
        # if username.startswith(string):
            result_list.append(username)

    return result_list

def save_report_to_file(path):
    file = open(path, "w")
    usernames, accounts = calculate_all_balances()
    for i in range(len(usernames)):
        file.write(usernames[i] + "|" + str(accounts[i]) + "\n")

    file.close()

def pretty_print_report():
    usernames, accounts = calculate_all_balances()
    print("\n{:^10}{:^10}".format("Users", "Balances"))
    print("="*20)
    for i in range(len(usernames)):
        print("{:^10}{:^10.2f}".format(usernames[i] , accounts[i]))


def print_data():
    for i in range(len(users)):
        print(users[i] + " " + actions[i] + " " + str(amounts[i]))


def main():
    load_data("../fajlovi/bank_log.txt")
    richest_user, max_amount = richest()
    print("Najbogatiji korisnik je", richest_user, "i ima", str(max_amount), "dinara")

    print(less_than(50000))

    save_report_to_file("../fajlovi/report.txt")
    pretty_print_report()

if __name__ == '__main__':
    main()