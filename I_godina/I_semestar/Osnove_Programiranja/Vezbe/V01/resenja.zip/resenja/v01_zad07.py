# chaos.py
# Program ilustruje haotično ponasanje

print("Ovaj program ilustruje haotično ponasanje")
x = eval(input("Unesite broj između 0 i 1: "))
for i in range(10):
    x = 2.0 * x * (1 - x)
    print(x)
