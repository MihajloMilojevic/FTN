# chaos.py
# Program ilustruje haotično ponasanje

print("Ovaj program ilustruje haotično ponasanje")
x, y = eval(input("Unesite dva broja između 0 i 1: "))
for i in range(10):
    x = 3.9 * x * (1 - x)
    y = 3.9 * y * (1 - y)
    print(x, y)
