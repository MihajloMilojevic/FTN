from math import sqrt

if __name__ == '__main__':
    a,b,c = eval(input("Unesite dužine stranica odvojene zarezom:"))
    s = a + b + c
    A = sqrt(s(s-a)(s-b)(s-c))

    print("Površina trougla je", A)