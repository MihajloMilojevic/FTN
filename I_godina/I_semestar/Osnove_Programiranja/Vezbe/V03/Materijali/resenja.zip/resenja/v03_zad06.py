from math import pi

if __name__ == '__main__':
    radius = eval(input("Unesite poluprečnik pice:"))
    price = eval(input("Unesite cenu pice:"))
    price_per_cm2 = price/(radius**2*pi)
    print("Cena po kvadratnom cm iznosi", price_per_cm2)