# ovakav način rešavanja odgovara načinu rešavanja nekih studenata
# može se diskutovati da li ima smisla aproksimirati rešenje ako smo u mogućnosti da izračunamo tačno pomoću sqrt
from math import sqrt

if __name__ == '__main__':
    x = eval(input("Unesite broj za koji želite da izračunate koren:"))
    n = int(input("Unesite broj pokušaja za pogađanje korena broja:"))

    guess = x/2
    sqrt_of_x = sqrt(x)

    for number in range(n):
        # ako se predlog dovoljno približi tačnom rešenju, prekidamo postupak
        if abs(sqrt_of_x-guess) <= 0.001:
            break
        guess = (guess+x/guess)/2

    print("Njutnovom metodom odredili smo da koren broja", x, "iznosi", guess)
    print("Koren broja", x, "pomoću funkcije sqrt iznosi", sqrt(x))

