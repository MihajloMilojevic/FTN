if __name__ == '__main__':
    H = 1.0079
    C = 12.011
    no_atoms_H = eval(input("Unesite broj atoma vodonika: "))
    no_atoms_C = eval(input("Unesite broj atoma ugljenika: "))
    mass = no_atoms_C*C+no_atoms_H*H
    print("Ukupna masa molekula iznosi", mass)