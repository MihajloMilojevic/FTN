if __name__ == '__main__':
    x1, y1 = eval(input("Unesite koordinate prve tačke odvojene zarezom:"))
    x2, y2 = eval(input("Unesite koordinate prve tačke odvojene zarezom:"))
    m = (y1-y2)/(x1-x2)
    print("Nagib prave iznosi", m)
    