# ovakav način rešavanja odgovara načinu rešavanja nekih studenata
# može se diskutovati da li ima smisla aproksimirati rešenje ako smo u mogućnosti da izračunamo tačno pomoću sqrt
from math import sqrt

if __name__ == '__main__':
    x = eval(input("Unesite broj za koji želite da izračunate koren:"))
    n = int(input("Unesite broj pokušaja za pogađanje korena broja:"))

    guess = x/2
    sqrt_of_x = sqrt(x)

    # ili umesto for petlje
    number_of_guesses = 0
    while abs(sqrt_of_x-guess) > 0.0001 and number_of_guesses <= n:
        guess = (guess + x / guess) / 2
        number_of_guesses += 1

    print("Njutnovom metodom odredili smo da koren broja", x, "iznosi", guess)
    print("Koren broja", x, "pomoću funkcije sqrt iznosi", sqrt(x))

