from math import sqrt

if __name__ == '__main__':
    x1, y1 = eval(input("Unesite koordinate prve tačke odvojene zarezom:"))
    x2, y2 = eval(input("Unesite koordinate prve tačke odvojene zarezom:"))
    d = sqrt((x1 - x2)**2 + (y1 - y2)**2)
    print("Udaljenost tačaka iznosi", d)
