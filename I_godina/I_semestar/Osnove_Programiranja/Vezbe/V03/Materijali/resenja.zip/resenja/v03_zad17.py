if __name__ == '__main__':
    n = int(input("Unesite koliko brojeva želite da saberete:"))
    sum = 0

    for number in range(n):
        sum += eval(input(str(number+1)+". Unesite broj:"))

    print("Suma unetih brojeva iznosi", sum)
