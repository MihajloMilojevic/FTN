if __name__ == '__main__':
    price_per_kg = 105
    delivery_per_kg = 18
    fixed_delivery = 15
    coffee_weight = eval(input("Unesite količinu kafe za dostavu u kg:"))
    price = (price_per_kg + delivery_per_kg) * coffee_weight + fixed_delivery
    print("Potrebno je platiti", price, "dinara.")

