# avg2.py
# Izracunava prosek dve ocene  
# Ilustruje unos vise podataka odjednom

print("Izracunava prosek dve ocene.")

score1, score2 = eval(input("Unesite dve ocene razdvojene zarezom: "))
average = (score1 + score2) / 2

print("Prosecna ocena je:", average)
