# convert.py
# Konverzija temperature iz Celzijusa u Farenhajte

celsius = eval(input("Unesite temperaturu u C >> "))
fahrenheit = 9/5 * celsius + 32
print("Temperatura je", fahrenheit, "stepeni Farenhajta.")
