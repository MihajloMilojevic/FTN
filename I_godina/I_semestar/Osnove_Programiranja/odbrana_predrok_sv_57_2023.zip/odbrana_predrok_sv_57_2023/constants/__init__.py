SEPARATOR = "|"
LOYALTY_SUM = 5000
LOYALTY_DISCOUNT_PERCENT = 10
PRICE_ADJUSTMENTS_PER_DAY = {
    0: 0,
    1: -50,
    2: 0,
    3: 0,
    4: 0,
    5: +50,
    6: +50
}