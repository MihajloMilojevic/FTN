import database.models as Models

projection_to_edit: Models.Projection = None