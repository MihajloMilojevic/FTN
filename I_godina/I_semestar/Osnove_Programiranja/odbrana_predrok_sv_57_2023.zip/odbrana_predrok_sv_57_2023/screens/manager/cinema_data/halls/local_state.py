import database.models as Models

sala_to_edit: Models.Hall = None