from database.models import Showtime, Ticket

ticket: Ticket = None

showtime_id: str = None
showtime: Showtime = None
seating_plan: list[list[str]] = None