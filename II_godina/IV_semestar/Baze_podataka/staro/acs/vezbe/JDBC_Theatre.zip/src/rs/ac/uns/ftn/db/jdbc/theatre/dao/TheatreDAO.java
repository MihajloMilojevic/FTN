package rs.ac.uns.ftn.db.jdbc.theatre.dao;

import rs.ac.uns.ftn.db.jdbc.theatre.model.Theatre;

public interface TheatreDAO extends CRUDDao<Theatre, Integer> {
}
