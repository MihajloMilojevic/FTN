package rs.ac.uns.ftn.db.jdbc.theatre.service;

import rs.ac.uns.ftn.db.jdbc.theatre.dao.PlayDAO;
import rs.ac.uns.ftn.db.jdbc.theatre.dao.impl.PlayDAOImpl;

public class PlayService {
	private static final PlayDAO playDAO = new PlayDAOImpl();
	
}
