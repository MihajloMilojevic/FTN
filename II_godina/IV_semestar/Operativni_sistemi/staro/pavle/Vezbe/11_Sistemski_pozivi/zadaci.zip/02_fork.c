/*
 * Napisati program koji klonira svoj proces, i zatim:
 *
 * Originalni proces treba da ispisuje slovo A odredjeni broj puta sa
 * pauzom od 2 sekunde izmedju ispisa.
 * Kopija treba da ispisuje slovo B odredjeni broj puta sa pauzom od 2
 * sekunde izmedju ispisa.
 *
 * Ukoliko je PID kopije paran broj, kopija treba da ceka 1 sekund pre
 * nego sto pocne sa ispisima, a u suprotnom, originalni proces treba
 * da ceka 1 sekund pre nego sto pocne sa ispisima.
 */

#include <unistd.h>

#define BROJ_PUTA 5

int main(int argc, char *argv[])
{
    /* Implementirati... */
}
