#!/bin/bash


# TODO implementirati
