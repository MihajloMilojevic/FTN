#include <iostream>

int main() {
    cout << "Hello, World!" << std::endl;
    return 0;
}