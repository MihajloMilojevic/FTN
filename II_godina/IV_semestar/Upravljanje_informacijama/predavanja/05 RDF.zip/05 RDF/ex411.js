{
  "head": {
    "vars": [ "s" , "o" ]
  } ,
  "results": {
    "bindings": [
      {
        "s": { "type": "uri" , "value": "http://learningsparql.com/ns/data#id3" } ,
        "o": { "datatype": "http://www.w3.org/2001/XMLSchema#boolean" ,
               "type": "typed-literal" , "value": "true" }
      } ,
      {
        "s": { "type": "uri" , "value": "http://learningsparql.com/ns/data#id1" } ,
        "o": { "type": "literal" , "value": "book" }
      } ,
      {
        "s": { "type": "uri" , "value": "http://learningsparql.com/ns/data#id4" } ,
        "o": { "type": "bnode" , "value": "b0" }
      } ,
      {
        "s": { "type": "uri" , "value": "http://learningsparql.com/ns/data#id2" } ,
        "o": { "type": "literal" , "xml:lang": "en-US" , "value": "5 bucks" }
      } ,
      {
        "s": { "type": "uri" , "value": "http://learningsparql.com/ns/data#id5" } ,
        "o": { "datatype": "http://www.w3.org/2001/XMLSchema#integer" ,
               "type": "typed-literal" , "value": "3" }
      }
    ]
  }
}
