{ "head": { "link": [], "vars": ["film", "title"] },
 "results": 
  {"distinct": false, "ordered": true, 
   "bindings": [

    {"film": 
     { "type": "uri", 
       "value": "http://dbpedia.org/resource/The_Night_of_the_Hunter_%28film%29"},
     "title": 
      { "type": "literal", "xml:lang": "en", 
        "value": "The Night of the Hunter (film)" 
      }
    },

    {"film": 
     { "type": "uri", 
       "value": "http://dbpedia.org/resource/The_Man_on_the_Eiffel_Tower" 
     }, 
     "title": 
      { "type": "literal", "xml:lang": "en", 
         "value": "The Man on the Eiffel Tower" 
      }
    } 

   ]
 } 
}

