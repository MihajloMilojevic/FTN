package automat;

/**
 * U ovu klasu se mogu dodavati sve potrebne konstante za rad aplikacije
 *
 */

public abstract class Konstante {
	public static final int MAX_BROJ_MESTA = 10;	
}
