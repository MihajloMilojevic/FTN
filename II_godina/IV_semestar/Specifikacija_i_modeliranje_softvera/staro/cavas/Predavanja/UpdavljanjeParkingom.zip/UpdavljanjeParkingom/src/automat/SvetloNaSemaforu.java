package automat;

public enum SvetloNaSemaforu {	
	Crveno, Zeleno
}

