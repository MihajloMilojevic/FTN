package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.time.format.DateTimeParseException;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.UserController;
import model.User;
import utils.MissingValueException;

public class ProfileDialog extends JDialog {

	private User userModel;
	private UserController userController;

	private JTextField tfName, tfSurname, tfUsername, tfDateOfBirth;
	private JButton btnEdit;

	public ProfileDialog(User user, UserController userController) {
		super();
		setSize(500, 350);
		setLocationRelativeTo(null);
		setTitle("Edit User Profile");

		this.userModel = user;
		this.userController = userController;

		JPanel contentPanel = new JPanel(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(20, 20, 20, 20));  // padding

		Font font = new Font("SansSerif", Font.PLAIN, 16);

		Box box = Box.createVerticalBox();

		JLabel lblHeader = new JLabel("Make changes to your profile:");
		lblHeader.setFont(new Font("SansSerif", Font.BOLD, 18));
		lblHeader.setAlignmentX(CENTER_ALIGNMENT);
		box.add(lblHeader);
		box.add(Box.createVerticalStrut(15));

		box.add(createFieldPanel("Name:", tfName = new JTextField(userModel.getName()), font));
		box.add(createFieldPanel("Surname:", tfSurname = new JTextField(userModel.getSurname()), font));
		box.add(createFieldPanel("Username:", tfUsername = new JTextField(userModel.getUsername()), font));
		box.add(createFieldPanel("Date of Birth:", tfDateOfBirth = new JTextField(userModel.getDateOfBirth().toString()), font));

		contentPanel.add(box, BorderLayout.CENTER);

		btnEdit = new JButton("Save Changes");
		btnEdit.setPreferredSize(new Dimension(160, 40));
		btnEdit.addActionListener((ActionEvent e) -> makeProfileChanges());

		JPanel buttonPanel = new JPanel();
		buttonPanel.setBorder(new EmptyBorder(10, 0, 0, 0));
		buttonPanel.add(btnEdit);

		contentPanel.add(buttonPanel, BorderLayout.SOUTH);

		add(contentPanel);
	}

	private JPanel createFieldPanel(String labelText, JTextField textField, Font font) {
		JLabel label = new JLabel(labelText);
		label.setFont(font);
		label.setPreferredSize(new Dimension(120, 30));

		textField.setPreferredSize(new Dimension(250, 30));

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
		panel.add(label);
		panel.add(textField);

		return panel;
	}

	private void makeProfileChanges() {
		try {
			userController.makeProfileChanges(getNameText(), getSurnameText(), getUsernameText(), getDateOfBirthText());
			JOptionPane.showMessageDialog(this, "Profile successfully updated.", "Success", JOptionPane.INFORMATION_MESSAGE);
			this.setVisible(false);
		} catch (MissingValueException e) {
			JOptionPane.showMessageDialog(this, e.getValueName() + " is not entered!", "Error", JOptionPane.ERROR_MESSAGE);
		} catch (DateTimeParseException e) {
			JOptionPane.showMessageDialog(this, "Entered date is not in valid format. Required format: yyyy-mm-dd.",
					"Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private String getNameText() {
		return tfName.getText().trim();
	}

	private String getSurnameText() {
		return tfSurname.getText().trim();
	}

	private String getUsernameText() {
		return tfUsername.getText().trim();
	}

	private String getDateOfBirthText() {
		return tfDateOfBirth.getText().trim();
	}
}
