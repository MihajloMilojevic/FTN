package controller;

import java.time.LocalDate;

import model.User;
import utils.MissingValueException;

public class UserController {
	
	private User user;
	
	public UserController(User user) {
		this.user = user;
	}
	
	public void makeProfileChanges(String name, String surname, String username, String dateOfBirth) throws MissingValueException {
		if (checkIfNullOrEmpty(name)) {
			throw new MissingValueException("name");
		}
		else if (checkIfNullOrEmpty(surname)) {
			throw new MissingValueException("surname");
		}
		else if (checkIfNullOrEmpty(username)) {
			throw new MissingValueException("username");
		} 
		else if (checkIfNullOrEmpty(dateOfBirth)) {
			throw new MissingValueException("dateOfBirth");
		}
		
		LocalDate date = LocalDate.parse(dateOfBirth); // possible throw of DateTimeParseException
		
		user.updateProfile(name, surname, username, date);
	}
	
	private boolean checkIfNullOrEmpty(String value) {
		return value == null || value.equals("");
	}
	
}
