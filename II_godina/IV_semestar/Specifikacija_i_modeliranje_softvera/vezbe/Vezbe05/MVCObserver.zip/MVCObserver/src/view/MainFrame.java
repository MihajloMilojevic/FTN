package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import controller.UserController;
import model.User;

public class MainFrame extends JFrame {
	
	private JButton btnProfile;
	private ProfileView profileView;
	
	public MainFrame() {
		super();

		setTitle("User profile");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setSize(600, 400);
		setLocationRelativeTo(null);
		
		User user = new User("Milan", "Milic", "Miki123", LocalDate.parse("1995-08-16"));
		UserController userController = new UserController(user);
		
		profileView = new ProfileView(user);
		add(profileView, BorderLayout.CENTER);

		btnProfile = new JButton("Edit your profile");
		btnProfile.setPreferredSize(new Dimension(200, 40));
		btnProfile.addActionListener((ActionEvent e) -> {
			ProfileDialog profileDialog = new ProfileDialog(user, userController);
			profileDialog.setVisible(true);
		});

		// Panel za dugme sa marginama (praznim prostorom oko dugmeta)
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBorder(new EmptyBorder(10, 0, 20, 0)); // gore, levo, dole, desno margine
		buttonPanel.add(btnProfile);

		add(buttonPanel, BorderLayout.SOUTH);
	}
	
}
