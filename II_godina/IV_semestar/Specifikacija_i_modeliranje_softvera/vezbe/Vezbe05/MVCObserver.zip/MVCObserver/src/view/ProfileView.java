package view;

import model.User;
import observer.Observer;
import observer.ProfileUpdateEvent;

import javax.swing.*;
import java.awt.*;

public class ProfileView extends JPanel implements Observer {

	private User user;
	private JTextField tfName, tfSurname, tfUsername, tfDateOfBirth;

	public ProfileView(User user) {
		setLayout(new BorderLayout());

		this.user = user;
		this.user.addObserver(this);

		Font font = new Font("SansSerif", Font.PLAIN, 16);

		Box box = Box.createVerticalBox();
		box.setAlignmentX(LEFT_ALIGNMENT);

		box.add(createFieldPanel("Name: ", user.getName(), font));
		box.add(createFieldPanel("Surname: ", user.getSurname(), font));
		box.add(createFieldPanel("Username: ", user.getUsername(), font));
		box.add(createFieldPanel("Date of birth: ", user.getDateOfBirth().toString(), font));

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BorderLayout());
		centerPanel.add(box, BorderLayout.NORTH);

		add(centerPanel, BorderLayout.CENTER);
	}

	private JPanel createFieldPanel(String labelText, String fieldValue, Font font) {
		JLabel label = new JLabel(labelText);
		label.setFont(font);
		label.setPreferredSize(new Dimension(130, 30));

		JTextField textField = new JTextField(fieldValue);
		textField.setEditable(false);
		textField.setPreferredSize(new Dimension(320, 30));
		textField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

		JPanel panel = new JPanel(new BorderLayout(10, 0));
		panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		leftPanel.add(label);

		JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		rightPanel.add(textField);

		panel.add(leftPanel, BorderLayout.WEST);
		panel.add(rightPanel, BorderLayout.CENTER);

		// Vezivanje polja
		switch (labelText) {
			case "Name: " -> tfName = textField;
			case "Surname: " -> tfSurname = textField;
			case "Username: " -> tfUsername = textField;
			case "Date of birth: " -> tfDateOfBirth = textField;
		}
		return panel;
	}

	private void updateProfileView(String name, String surname, String username, String dateOfBirth) {
		tfName.setText(name);
		tfSurname.setText(surname);
		tfUsername.setText(username);
		tfDateOfBirth.setText(dateOfBirth);
	}

	@Override
	public void updatePerformed(ProfileUpdateEvent e) {
		updateProfileView(e.getName(), e.getSurname(), e.getUsername(), e.getDateOfBirth());
		revalidate();
		repaint();
	}
}
