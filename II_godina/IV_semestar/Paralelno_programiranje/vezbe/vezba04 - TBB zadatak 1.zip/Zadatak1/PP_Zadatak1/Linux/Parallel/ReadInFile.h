#ifndef _READ_IN_FILE_H_
#define _READ_IN_FILE_H_

#include <iostream>
#include <fstream>
#include <string>
#include <queue>
#include "defines.h"

using namespace std;

RetVal ReadInFile(string fileName);

#endif
