#ifndef _HIGH_PASS_FILTER_H_
#define _HIGH_PASS_FILTER_H_

#include <queue>
#include "defines.h"

using namespace std;

RetVal HighPassFilter(float alpha);

#endif
