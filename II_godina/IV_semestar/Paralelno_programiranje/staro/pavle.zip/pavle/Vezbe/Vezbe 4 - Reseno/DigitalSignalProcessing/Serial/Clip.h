#ifndef _CLIP_H_
#define _CLIP_H_

#include <queue>
#include <vector>
#include "defines.h"

using namespace std;

RetVal Clip(char lowerValue, char upperValue);

#endif
