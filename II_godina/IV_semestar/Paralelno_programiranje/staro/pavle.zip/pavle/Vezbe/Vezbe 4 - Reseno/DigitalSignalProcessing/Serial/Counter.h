#ifndef _COUNTER_H_
#define _COUNTER_H_

#include <queue>
#include <vector>
#include "defines.h"

using namespace std;

RetVal Counter();

#endif
