#ifndef _CLIP_H_
#define _CLIP_H_

#include <vector>
#include "defines.h"

using namespace std;

RetVal Clip(int lowerValue, int upperValue);

#endif
