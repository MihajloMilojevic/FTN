#ifndef _CLIP_H_
#define _CLIP_H_

#include <vector>
#include <omp.h>

#include "defines.h"

using namespace std;

//RetVal Clip(char lowerValue, char upperValue);
RetVal Clip(int lowerValue, int upperValue);

#endif
