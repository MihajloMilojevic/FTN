#ifndef _HIGH_PASS_FILTER_H_
#define _HIGH_PASS_FILTER_H_

#include "defines.h"
#include <vector>
#include <omp.h>

using namespace std;

RetVal Filter();

#endif
