#ifndef _WRITE_OUT_FILE_H_
#define _WRITE_OUT_FILE_H_

#include <iostream>
#include <fstream>
#include <string>
#include "defines.h"

using namespace std;

RetVal WriteOutFile(string fileName);

#endif
