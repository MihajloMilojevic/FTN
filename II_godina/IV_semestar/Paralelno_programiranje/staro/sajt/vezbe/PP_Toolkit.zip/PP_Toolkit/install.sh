#!/bin/bash

sudo sh ./l_BaseKit_p_2022.1.2.146.sh

sudo update-alternatives --install /usr/bin/python python /usr/bin/python3 10

sudo apt -y install pkg-config
