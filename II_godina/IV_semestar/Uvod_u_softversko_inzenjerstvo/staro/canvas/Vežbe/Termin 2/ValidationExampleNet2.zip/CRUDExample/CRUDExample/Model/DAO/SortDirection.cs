﻿namespace CRUDExample.Model.DAO
{

    public enum SortDirection
    {
        Ascending,
        Descending
    }
}