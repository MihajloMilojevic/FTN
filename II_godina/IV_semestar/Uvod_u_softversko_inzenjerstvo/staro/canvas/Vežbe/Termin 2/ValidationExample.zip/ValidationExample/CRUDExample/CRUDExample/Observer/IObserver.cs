﻿namespace CRUDExample.Observer
{
    public interface IObserver
    {
        void Update();
    }
}