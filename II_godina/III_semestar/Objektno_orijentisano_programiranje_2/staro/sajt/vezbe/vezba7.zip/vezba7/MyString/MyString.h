#pragma once

#include <iostream>

class MyString
{
};

