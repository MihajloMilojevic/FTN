
#include <stdio.h>

typedef enum {
	CHICKEN,
	EGG,
	SPACESHIP,
	ROCKET
} type_t;


typedef struct {
	int x;
	int y;
	int w;
	int h;
	type_t type;
} GeomObj;

typedef void (anim_fun_t*)(GeomObj*);
anim_fun_t anim[] = {
	anim_chicken,
	anim_egg,
	anim_rocket,
	anim_spaceship
}

typedef void (draw_fun_t*)(GeomObj*);
draw_fun_t anim[] = {
	draw_chicken,
	draw_egg,
	draw_rocket,
	draw_spaceship
}

typedef struct {
	anim_fun_t anim;
	draw_fun_t draw;
} fun_t;

fun_t virtual_table[] = {
	{ 
		anim_chicken,
		draw_chicken
	},
	{
		
	}
}

bool collision_detection(GeomObj* o1, GeomObj* o2) {

}

bool reaction(GeomObj* o1, GeomObj* o2) {
	type_t t1 = o1->type;
	type_t t2 = o2->type;
	
	switch(t1){
		case CHICKEN:
			switch(t2){
				case CHICKEN:
					break;
			}
			break;
		case EGG:
			
	}
}

int main() {
	anim[o1->type](o1);
	
    printf("Hello there!\n");
    return 0;
}
