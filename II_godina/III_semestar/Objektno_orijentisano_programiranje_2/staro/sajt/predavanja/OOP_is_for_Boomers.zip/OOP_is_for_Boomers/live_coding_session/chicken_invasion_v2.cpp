
#include <iostream>
using namespace std;



int main() {
	cout << "Hello there!" << endl;

	return 0;
}