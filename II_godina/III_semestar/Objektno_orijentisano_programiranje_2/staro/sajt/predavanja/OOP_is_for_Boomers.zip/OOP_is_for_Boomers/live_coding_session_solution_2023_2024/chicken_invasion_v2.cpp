
#include <iostream>
using namespace std;

class GeomObj {
public:
	int x;
	int y;
	int w;
	int h;	
	
	bool collision(const GeomObj&) {
		a;lksjdfl;kaj
	}
};

class Chicken : public GeomObj {
	
	void draw() {
		
	}
	
	void reaction(Rocket& o2) {
		
	}
	
	void reaction(Spaceship& o2) {
		
	}
	void reaction(Egg& o2) {
		nohting
	}
	void reaction(Chicken& o2) {
		nohting
	}
	void reaction(Asterioid& o2) {
		nohting
	}
	void reaction(Package& o2) {
		nohting
	}
};


int main() {
	cout << "Hello there!" << endl;

	return 0;
}
