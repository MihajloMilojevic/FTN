
#include <stdio.h>

int main() {
    printf("Hello there!\n");
    return 0;
}