
#include <iostream>
using namespace std;

class Pet {
public:
	string name;
};

string meets(const Pet& a, const Pet& b) {
	return "FALLBACK";
}

void encounter(const Pet& a, const Pet& b) {
	string verb = meets(a, b);
	cout << a.name << " meets " << b.name
		<< " and " << verb << endl;
}

class Dog : public Pet {
public:
	Dog(const string& name) {
		this->name = name;
	}
};
class Cat : public Pet {
public:
	Cat(const string& name) {
		this->name = name;
	}
};

string meets(const Dog& a, const Dog& b) {
	return "sniffs";
}
string meets(const Dog& a, const Cat& b) {
	return "chases";
}
string meets(const Cat& a, const Dog& b) {
	return "hisses";
}
string meets(const Cat& a, const Cat& b) {
	return "slinks";
}

int main() {
	Dog fido("Fido");
	Dog rex("Rex");
	Cat whiskers("Whiskers");
	Cat spots("Spots");

	encounter(fido, rex);
	encounter(fido, whiskers);
	encounter(whiskers, rex);
	encounter(whiskers, spots);

	return 0;
}