

#ifdef CONFIG_INC_TEST
// Search directories.
#include <utils.hpp>
#else
// Include from same directory as this file.
#include "utils.hpp"
#endif

#include <iostream>
using namespace std;

#include "legacy.h"

#include "helpers/helpers.hpp"

#include <plugin.hpp>

int main() {
	cout << "Hello there!" << endl;
	
	helpers_init();
	utils_init();
	legacy_init(1000);
	plugin_init(uint32_t(PLUGIN_IDX));
	plugin_init(float(PLUGIN_IDX));
	
	return 0;
}
