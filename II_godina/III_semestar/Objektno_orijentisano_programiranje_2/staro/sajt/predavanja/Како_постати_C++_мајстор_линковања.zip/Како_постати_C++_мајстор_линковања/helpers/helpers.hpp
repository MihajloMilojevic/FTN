
#pragma once

void helpers_init();
