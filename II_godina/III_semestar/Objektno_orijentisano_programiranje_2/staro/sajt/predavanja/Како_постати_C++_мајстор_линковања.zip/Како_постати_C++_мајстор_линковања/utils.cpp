
#include "utils.hpp"

#include <iostream>
using namespace std;

void utils_init() {
	cout << "utils_init()" << endl;
	legacy_init(1);
}
