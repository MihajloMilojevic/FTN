
#ifndef LEGACY_H
#define LEGACY_H

#ifdef __cplusplus
extern "C" {
#endif
void legacy_init(int x);
#ifdef __cplusplus
}
#endif

#endif // LEGACY_H
