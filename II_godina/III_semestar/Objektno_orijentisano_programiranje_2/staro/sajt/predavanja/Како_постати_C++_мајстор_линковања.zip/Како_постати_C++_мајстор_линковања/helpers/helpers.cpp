
#include "helpers.hpp"

#include <iostream>
using namespace std;

void helpers_init() {
	cout << "helpers_init()" << endl;
}
