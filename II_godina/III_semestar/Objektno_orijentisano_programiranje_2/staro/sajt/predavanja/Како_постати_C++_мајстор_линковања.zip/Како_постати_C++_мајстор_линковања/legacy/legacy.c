
#include <stdio.h>

void legacy_init(int x) {
	printf("legacy_init(%d)\n", x);
	legacy_setup(2);
	legacy_setup(2.0);
}
