
#include <stdio.h>

void legacy_setup(int x) {
	printf("legacy_setup(%d)\n", x);
}
