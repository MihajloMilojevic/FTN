
#pragma once

#include <stdint.h>

void plugin_init(uint32_t x);
void plugin_init(double x);
