
#pragma once

#include "legacy.h"

void utils_init();
