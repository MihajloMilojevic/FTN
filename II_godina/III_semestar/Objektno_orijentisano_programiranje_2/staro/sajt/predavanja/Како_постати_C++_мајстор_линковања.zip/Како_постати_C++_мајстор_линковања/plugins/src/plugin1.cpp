
#include "../include/plugin.hpp"

#include <iostream>
using namespace std;

#define DEBUG(var) \
	do{ \
		cout << __FILE__ << ":" \
			<< __LINE__ << ":" \
			<< ' ' << __PRETTY_FUNCTION__ << " -> " \
			<< #var << " = " << var << endl; \
	}while(0)

void plugin_init(uint32_t x) {
	DEBUG(x);
}
void plugin_init(double x) {
	DEBUG(x);
}
