//============================================================================
// Name        : Flight.h
// Author      :
// Date        :
// Copyright   :
// Description :
//============================================================================
#pragma once

class Flight
{
	// your definition goes here
};
