#include <iostream>

#include "longInt.h"


using myInt = int; //typedef int myInt;


myInt fib(myInt n)
{
	myInt xN = 1;
	myInt xNm1 = 0;
	myInt count = 1;
	while (count < n)
	{
		myInt t = xN + xNm1;
		xNm1 = xN;
		xN = t;
		count = count + 1;
	}
	return xN;
}


int main(int argc, char* argv[])
{
	myInt res;
	res = fib(300);

	if (res == 222232244629420445529739893461909967206666939096499764990979600_mi)
		std::cout << res << "\n";
	else
		std::cout << "fail\n";

	return 0;
}
