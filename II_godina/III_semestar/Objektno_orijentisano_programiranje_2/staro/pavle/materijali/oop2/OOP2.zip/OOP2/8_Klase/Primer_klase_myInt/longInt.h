#ifndef __LONG_INT_H__
#define __LONG_INT_H__

#include <iostream>
#include <array>


class mi
{
public:
	mi() {}
	mi(int x);
	friend bool operator < (const mi& x, const mi& y);
	friend mi operator + (const mi& x, const mi& y);
	friend bool operator == (const mi& x, const mi& y);
	friend std::ostream& operator << (std::ostream& output, const mi& x);
	friend mi operator""_mi(const char* x);

protected:
	std::array<char, 70> m_x = { 0 };
	int m_size = 0;
};

#endif
