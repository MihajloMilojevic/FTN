#ifndef MY_GRAPH_GUARD
#define MY_GRAPH_GUARD

#include "Point.h"
#include "std_lib_facilities.h"

#include <vector>

using std::vector;

namespace My_graph_lib
{

class Shape {

};


class Line : Shape {
public:
	Line(Point x, Point y) : a(x), b(y) {}

	Point getA() const { return a; }
	Point getB() const { return b; }

private:
	Point a;
	Point b;
};


class Rectangle : Shape {
public:
	Rectangle(Point xy, int ww, int hh) : x(xy), w(ww), h(hh) {
		if (h <= 0 || w <= 0) error("Bad arguments");
	}

	Rectangle(Point a, Point b) : x(a), w(b.x - a.x), h(b.y - a.y) {
		if (h <= 0 || w <= 0) error("Bad arguments");
	}

	int height() const { return h; }
	int width() const { return w; }
	Point getX() const { return x; }

private:
	Point x;
	int w;
	int h;
};


class Open_polyline : Shape {
public:
	void add(const Point& x) { points.push_back(x); }

//private:
	vector<Point> points;
};

} // of namespace Graph_lib

#endif
