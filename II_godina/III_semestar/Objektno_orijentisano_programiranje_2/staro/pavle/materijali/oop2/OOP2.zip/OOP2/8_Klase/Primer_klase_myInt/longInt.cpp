#include "longInt.h"


mi::mi(int x)
{
	int i = 0;
	while (x != 0)
	{
		m_x[i++] = x % 10;
		x /= 10;
	}
	m_size = i;
}


bool operator < (const mi& x, const mi& y)
{
	if (x.m_size < y.m_size)
		return true;
	else if (x.m_size > y.m_size)
		return false;
	else
	{
		for (int i = x.m_size - 1; i >= 0; --i)
		{
			if (x.m_x[i] < y.m_x[i])
				return true;
			if (x.m_x[i] > y.m_x[i])
				return false;
		}
	}
	return false;
}


mi operator + (const mi& x, const mi& y)
{
	mi ret;

	int size = x.m_size > y.m_size ? x.m_size : y.m_size;
	char carry = 0;
	for (int i = 0; i < size; ++i)
	{
		char t = x.m_x[i] + y.m_x[i] + carry;
		carry = t / 10;
		ret.m_x[i] = t - (10 * carry);
	}

	if (carry != 0)
		ret.m_x[size++] = carry;

	ret.m_size = size;

	return ret;
}


bool operator == (const mi& x, const mi& y)
{
	return (x.m_size == y.m_size && x.m_x == y.m_x);
}


std::ostream& operator << (std::ostream& output, const mi& x)
{
	for (int i = x.m_size - 1; i >= 0; --i)
		output << static_cast<int>(x.m_x[i]);
	return output;
}


mi operator""_mi(const char* x)
{
	std::array<char, 70> tmpArr;
	char c = *x++;
	int i = 0;
	while (c != '\0')
	{
		c -= '0';
		tmpArr[i++] = c;
		c = *x++;
	}

	mi res;
	res.m_size = i;
	for (i = 0; i < res.m_size; ++i)
	{
		res.m_x[res.m_size - i - 1] = tmpArr[i];
	}
	
	return res;
}
