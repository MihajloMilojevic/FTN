#ifndef MY_GRAPH_GUARD
#define MY_GRAPH_GUARD

#include "Point.h"
#include "std_lib_facilities.h"

#include <FL/fl_draw.H>

#include <vector>

using std::vector;

namespace My_graph_lib
{

class Shape {
public:
	virtual void draw_lines() {};
};


class Line : Shape {
public:
	Line(Point x, Point y) : a(x), b(y) {}

	void draw_lines() {
		fl_line(a.x, a.y, b.x, b.y);
	}
private:
	Point a;
	Point b;
};


class Rectangle : Shape {
public:
	Rectangle(Point xy, int ww, int hh) : x(xy), w(ww), h(hh) {
		if (h <= 0 || w <= 0) error("Bad arguments");
	}

	Rectangle(Point a, Point b) : x(a), w(b.x - a.x), h(b.y - a.y) {
		if (h <= 0 || w <= 0) error("Bad arguments");
	}

	void draw_lines() {
		fl_rect(x.x, x.y, w, h);
	}

private:
	Point x;
	int w;
	int h;
};


class Open_polyline : Shape {
public:
	void add(const Point& x) { points.push_back(x); }

	void draw_lines() {
		for (unsigned int j = 1; j < points.size(); ++j) {
			fl_line(points[j - 1].x, points[j - 1].y,
				points[j].x, points[j].y);
		}
	}

private:
	vector<Point> points;
};

} // of namespace Graph_lib

#endif
