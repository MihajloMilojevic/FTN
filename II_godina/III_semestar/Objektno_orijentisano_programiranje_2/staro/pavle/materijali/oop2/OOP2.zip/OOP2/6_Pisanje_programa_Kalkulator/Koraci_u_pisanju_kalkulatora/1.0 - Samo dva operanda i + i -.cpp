#include <iostream>

using namespace std;

int main()
{
	double lval;
	double rval;
	double res;
	char op;

	cout << ">";

	cin >> lval >> op >> rval;

	if (op == '+')
		res = lval + rval;
	else
		res = lval - rval;

	cout << "=" << res << endl;

	return 0;
}
