#pragma once

int fib(int& last);
int fib(long& last);
int fib(long long& last);