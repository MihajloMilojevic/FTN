#include <string>


// Hex conversions
std::string uintToHex(unsigned int);
std::string addHex(const std::string&, const std::string&);
unsigned int hexToUint(const std::string&);
