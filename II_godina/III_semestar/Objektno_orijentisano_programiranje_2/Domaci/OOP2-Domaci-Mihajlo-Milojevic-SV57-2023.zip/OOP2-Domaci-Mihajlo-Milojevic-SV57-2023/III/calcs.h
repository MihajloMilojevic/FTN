#pragma once

void calcShort();
void calcInt();
void calcDouble();