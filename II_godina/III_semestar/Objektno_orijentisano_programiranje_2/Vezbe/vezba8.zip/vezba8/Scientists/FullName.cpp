#include "FullName.h"

using namespace std;

/*
@TODO: Complete the FullName class definition:
- add implementation for constructor with parameters
- add implementation for operator ==
- add implementation for get methods
*/

