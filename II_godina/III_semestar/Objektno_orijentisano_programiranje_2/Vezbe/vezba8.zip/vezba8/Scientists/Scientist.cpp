#include "Scientist.h"

/*
@TODO: Complete the Scientist class definition:
- add implementation for constructor with parameters
- add implementation for operator ==
- add implementation for operator <
- add implementation for get methods
*/

