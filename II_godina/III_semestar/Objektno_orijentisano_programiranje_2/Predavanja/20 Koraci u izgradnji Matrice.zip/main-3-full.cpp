﻿
#include "matrix-3-full.h"

#include <fstream>
#include <chrono>


using namespace MyMatrix;
using namespace std;

int g;

void foo(Matrix<>& x)
{
	g = x(5, 17); // служи само да спречи одстрањивање кода у main() као непотребног
}


void main()
{
	Matrix<> X(1000, 1000, ifstream("inputXMax.txt"));
	Matrix<> Y(1000, 1000, ifstream("inputYMax.txt"));

	Matrix<> Z(1000, 1000);
	auto t1 = chrono::high_resolution_clock::now();
	// Matrix<> Z(1000, 1000) = X + Y;
	Z = X + Y;
	foo(Z);
	auto t2 = chrono::high_resolution_clock::now();
	chrono::duration<double> time_span = chrono::duration_cast<std::chrono::duration<double>>(t2 - t1);
	cout << "It took me " << time_span.count() << " seconds.";

	return;
}
