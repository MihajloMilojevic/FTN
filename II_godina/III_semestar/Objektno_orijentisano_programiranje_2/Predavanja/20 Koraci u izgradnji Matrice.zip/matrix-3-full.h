﻿#ifndef __MATRIX_H__
#define __MATRIX_H__

/*
Ово је верзија Matrix класе која је направљена генерички, са ослањањем на Це++ шаблоне (темплејте).
Додат је конструктор који прима улазни ток из којег ће се садржај матрице иницијализовати,
као и оператор доделе, да би се омогућили изрази облика A = B + C
*/


#include <cassert>
#include <iostream>
#include "std_lib_facilities.h"

namespace MyMatrix
{

template<class T = int>
class Matrix;

template<class T> std::istream& operator >> (std::istream& is, Matrix<T>& m);

template<class T>
class Matrix
{
protected:
	T* m_elem;
	const int m_sz;
	const int m_d1;
	const int m_d2;

public:
	Matrix(int d1, int d2) : m_elem(new T[d1*d2]()), m_sz(d1*d2), m_d1(d1), m_d2(d2) {
		// Садржај матрице је неиницијализован
	}

	Matrix(int d1, int d2, std::istream& is)
		: m_elem(new T[d1*d2]()), m_sz(d1*d2), m_d1(d1), m_d2(d2) {
		is >> *this;
	}

	Matrix(const Matrix& X) : m_elem(new T[X.m_sz]()), m_sz(X.m_sz), m_d1(X.m_d1), m_d2(X.m_d2) {
		T* pi = X.m_elem;
		T* po = m_elem;
		for (int i = 0; i < X.m_sz; ++i)
			*po++ = *pi++;
	}

	Matrix& operator=(const Matrix& X) {
		if (m_elem == X.m_elem) return *this;

		if (m_d1 != X.m_d1 || m_d2 != X.m_d2) error("lose dimenzije");

		// пошто су дименизије исте, онда је и m_sz исто, па нема потребе за новим заузимањем меморије

		T* pi = X.m_elem;
		T* po = m_elem;
		for (int i = 0; i < m_sz; ++i)
			*po++ = *pi++;

		return *this;
	}

	~Matrix() {
		delete[] m_elem;
	}

	T& operator()(int i, int j) {
		return m_elem[i * m_d1 + j];
	}

	const T& operator()(int i, int j) const {
		return m_elem[i * m_d1 + j];
	}

	T* data() { return m_elem; }
	const T* data() const { return m_elem; }

	int d1() const { return m_d1; }
	int d2() const { return m_d2; }
};


template<class T> Matrix<T> operator+(const Matrix<T>& A, const Matrix<T>& B)
{
	if (A.d1() != B.d1() || A.d2() != B.d2()) error("Matrix dimension missmatch.");
	int n = A.d1();
	int m = A.d2();

	Matrix<T> C(n, m);

	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			C(i, j) = A(i, j) + B(i, j);
		}
	}

	return C;
}


template<class T> std::istream& operator >> (std::istream& is, Matrix<T>& m)
{
	char ch;
	is >> ch;

	if (ch != '{') error("nedostaje '{'");

	for (int i = 0; i < m.d1(); ++i) {
		for (int j = 0; j < m.d2(); ++j) {
			is >> m(i, j);
		}
	}

	is >> ch;

	if (ch != '}') error("nedostaje '}'");

	return is;
}


template<class T> std::ostream& operator << (std::ostream& os, const Matrix<T>& m)
{
	os << "{\n";

	for (int i = 0; i < m.d1(); ++i) {
		for (int j = 0; j < m.d2(); ++j) {
			os << m(i, j) << " ";
		}
		os << '\n';
	}

	os << "}\n";

	return os;
}

}

#endif
