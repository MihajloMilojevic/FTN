﻿#ifndef __MATRIX_H__
#define __MATRIX_H__

/*
Ово је верзија Matrix класе која је направљена генерички, али ослањањем на void* показивач као базни тип.
Оваква имплементација личи на Јава подршку генеричким класама.
void* би одговарао Object класи у Јави, а показивачи би били Јава референце.
У функцијама operator+, operator<< и operator>> мора се специфицирати тип елементарног податка,
али те функије само користе класу Matrix, која се не мења без обзира на елементарни тип.
*/


#include <cassert>
#include <iostream>
#include "std_lib_facilities.h"

namespace MyMatrix
{
typedef void* T;
class Matrix
{
protected:
	T* m_elem;
	const int m_sz;
	const int m_d1;
	const int m_d2;

public:
	Matrix(int d1, int d2) : m_elem(new T[d1*d2]()), m_sz(d1*d2), m_d1(d1), m_d2(d2) {
		// Садржај матрице је неиницијализован
	}

	Matrix(const Matrix& X) : m_elem(new T[X.m_sz]()), m_sz(X.m_sz), m_d1(X.m_d1), m_d2(X.m_d2) {
		T* pi = X.m_elem;
		T* po = m_elem;
		for (int i = 0; i < X.m_sz; ++i) {
			*po++ = *pi++; // овде радимо само плитко копирање елемента!!!
		}
		/* горњи код је еквивалендан са овим:
		for (int i = 0; i < X.m_sz; ++i)
			m_elem[i] = X.m_elem[i];
		*/
		/* а овако би изгледало дубоко копирање, али када знамо да су елементи типа int:
		for (int i = 0; i < X.m_sz; ++i) {
			*po++ = new int(*static_cast<int*>(pi++)); 
		}
		*/
	}

	~Matrix() {
		/*for (int i = 0; i < m_sz; ++i)
			delete static_cast<int*>(m_elem[i]);*/
		delete[] m_elem;
	}

	T& operator()(int i, int j) {
		return m_elem[i * m_d1 + j];
	}

	const T& operator()(int i, int j) const {
		return m_elem[i * m_d1 + j];
	}

	T* data() { return m_elem; }
	const T* data() const { return m_elem; }

	int d1() const { return m_d1; }
	int d2() const { return m_d2; }
};


Matrix operator+(const Matrix& A, const Matrix& B)
{
	if (A.d1() != B.d1() || A.d2() != B.d2()) error("Matrix dimension missmatch.");
	int n = A.d1();
	int m = A.d2();

	Matrix C(n, m);

	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			int x = *static_cast<int*>(A(i, j));
			int y = *static_cast<int*>(B(i, j));
			C(i, j) = new int(x + y);
		}
	}

	return C;
}


std::istream& operator >> (std::istream& is, Matrix& m)
{
	char ch;
	is >> ch;

	if (ch != '{') error("nedostaje '{'");

	for (int i = 0; i < m.d1(); ++i) {
		for (int j = 0; j < m.d2(); ++j) {
			int* tmp = new int();
			is >> *tmp;
			m(i, j) = tmp;
		}
	}

	is >> ch;

	if (ch != '}') error("nedostaje '}'");

	return is;
}


std::ostream& operator << (std::ostream& os, const Matrix& m)
{
	os << "{\n";

	for (int i = 0; i < m.d1(); ++i) {
		for (int j = 0; j < m.d2(); ++j) {
			const int* tmp = static_cast<const int*>(m(i, j));
			os << *tmp << " ";
		}
		os << '\n';
	}

	os << "}\n";

	return os;
}

}

#endif
