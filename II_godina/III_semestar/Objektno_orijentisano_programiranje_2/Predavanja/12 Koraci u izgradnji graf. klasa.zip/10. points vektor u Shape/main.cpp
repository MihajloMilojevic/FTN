﻿#include "MyWindow.h"
#include "MyGraph.h"

int main(int argc, char** argv)
{
	using namespace My_graph_lib;

	Point tl(100, 200);

	My_window win(tl, 600, 400, "Canvas");

	Line l1(Point(10, 10), Point(200, 200));
	Line l2(Point(10, 50), Point(200, 250));

	win.attach(l1);
	win.attach(l2);

	My_graph_lib::Rectangle r(Point(200, 200), 100, 50);

	win.attach(r);

	OpenPolyline poly_rect;
	poly_rect.add(Point(100, 50));
	poly_rect.add(Point(200, 50));
	poly_rect.add(Point(200, 100));
	poly_rect.add(Point(100, 100));
	poly_rect.add(Point(50, 75));

	win.attach(poly_rect);

	gui_main();	// пренеси контролу графичком подсистему

	return 0;
}
