#ifndef MY_GRAPH_GUARD
#define MY_GRAPH_GUARD

#include "Point.h"
#include "std_lib_facilities.h"

#include <FL/fl_draw.H>

#include <vector>

using std::vector;

namespace My_graph_lib
{

class Shape {
public:
	virtual void draw_lines() {
		if (points.size() > 1) {
			for (unsigned int j = 1; j < points.size(); ++j){
				fl_line(points[j - 1].x, points[j - 1].y,
					points[j].x, points[j].y);
			}
		}
	};

protected:
	void add(const Point& p) { points.push_back(p); }
	vector<Point> points;
};


class Line : public Shape {
public:
	Line(Point p1, Point p2) {
		add(p1);
		add(p2);
	};
};


class Rectangle : public Shape {
public:
	Rectangle(Point xy, int ww, int hh) : w(ww), h(hh) {
		add(xy);
		if (h <= 0 || w <= 0) error("Bad arguments");
	}

	Rectangle(Point a, Point b) : w(b.x - a.x), h(b.y - a.y) {
		add(a);
		if (h <= 0 || w <= 0) error("Bad arguments");
	}

	void draw_lines() {
		fl_rect(points[0].x, points[0].y, w, h);
	}

private:
	int w;
	int h;
};


class OpenPolyline : public Shape {
public:
	OpenPolyline() {}

	void add(const Point& x) { Shape::add(x); }
};

} // of namespace Graph_lib

#endif
