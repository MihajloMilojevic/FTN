#ifndef MY_GRAPH_GUARD
#define MY_GRAPH_GUARD

#include "Point.h"
#include "std_lib_facilities.h"


#endif
