package main

import (
	"fmt"
	"crypto/sha1"
	"encoding/hex"
)

type MerkleTree struct {
	root *Node
}

type Node struct {
	data []byte
	left *Node
	right *Node
}

func (n *Node) String() string {
	return hex.EncodeToString(n.data[:])
}

func Hash(data []byte) [20]byte {
	return sha1.Sum(data)
}
