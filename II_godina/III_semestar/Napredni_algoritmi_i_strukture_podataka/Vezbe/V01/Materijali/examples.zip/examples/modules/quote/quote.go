package quote

import (
	"fmt"
	"rsc.io/quote"
)

func PrintQuote() {
	fmt.Println(quote.Go())
}
