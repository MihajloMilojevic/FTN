use video

db.movieDetails.find().count()