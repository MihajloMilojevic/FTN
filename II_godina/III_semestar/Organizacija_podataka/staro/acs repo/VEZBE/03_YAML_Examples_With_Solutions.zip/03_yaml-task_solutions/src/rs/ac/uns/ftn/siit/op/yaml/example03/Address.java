package rs.ac.uns.ftn.siit.op.yaml.example03;

public class Address {
	public String lines;
	public String city;
	public String state;
	public String postal;

	@Override
	public String toString() {
		return "Address [lines=" + lines + ", city=" + city + ", state=" + state + ", postal=" + postal + "]";
	}

}
