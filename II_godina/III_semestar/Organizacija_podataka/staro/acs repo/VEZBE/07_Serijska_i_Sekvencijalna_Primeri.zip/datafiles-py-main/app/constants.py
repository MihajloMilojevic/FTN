#!/usr/bin/python

ATTRIBUTES = ["id", "name", "q", "status"]
FMT = "i10sdi"
CODING = "ascii"

F = 3
B = 5