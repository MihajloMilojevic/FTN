#!/usr/bin/python

ATTRIBUTES = ["id", "name", "q", "status"]
FMT = "i10sdi"
CODING = "ascii"

F = 3  # Broj slogova u bloku/baketu
B = 5  # Broj baketa (relevantno za staticku rasutu organizaciju)
