from pprint import pprint

import avro.schema

from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter


def write_avro_file(file_path, schema_file_path, data):
    with open(schema_file_path, 'r') as avro_schema_file, \
            open(file_path, 'wb') as avro_file, \
            DataFileWriter(avro_file, DatumWriter(), avro.schema.parse(avro_schema_file.read())) as writer:
        for row in data:
            writer.append(row)


def read_avro_file(file_path):
    with open(file_path, 'rb') as avro_file, \
            DataFileReader(avro_file, DatumReader()) as reader:
        records = [record for record in reader]
        return records


if __name__ == "__main__":
    students = [
        {"id": 1, "name": "Alice", "age": 20, "subjects": ["Math", "Physics"]},
        {"id": 2, "name": "Bob", "age": 21, "subjects": ["Biology", "Chemistry"]}
    ]

    write_avro_file("students.avro", "student.avsc", students)
    pprint(read_avro_file("students.avro"))
