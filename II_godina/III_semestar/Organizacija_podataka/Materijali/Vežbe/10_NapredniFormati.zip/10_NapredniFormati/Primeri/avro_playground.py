from pprint import pprint

import avro.schema
import json

from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter

# Define a basic Avro schema made of primitive types
simple_schema = {
    "type": "string"
}

# Define Avro schemas for a person and a company by using both primitive and complex types
person_schema = {
    # Note: an example of a RECORD type
    "type": "record",
    "name": "Person",  # required for type Record
    "namespace": "rs.uns.ac.ftn.siit.op",  # optional - a JSON string that qualifies the name
    "aliases": ["Employee"],  # optional - a JSON array of strings, providing alternate names for this record
    "fields": [  # required - a JSON array, listing fields
        {"name": "name", "type": "string"},

        # Note: using [] for a type makes it the UNION type
        # Note: using the union type enables using multiple types for a field
        # Note: using null in a union makes a field optional
        {"name": "age", "type": ["null", "int"]},

        # Note: an examole use of the ARRAY type
        # Note: type of the items must be declared
        {"name": "emails", "type": {"type": "array", "items": "string"}},

        # Note: an example use of the ENUM type
        {"name": "position", "type": {"type": "enum", "name": "PositionEnum", "symbols": ["CLERK", "MANAGER"]}},

        # Note: an example use of the MAP type
        # Note: maps enable using arbitrary key-value pairs
        {"name": "tags", "type": {"type": "map", "values": "string"}}

    ]
}

company_schema = {
    "type": "record",
    "name": "Company",
    "namespace": "rs.uns.ac.ftn.siit.op",
    "fields": [
        {"name": "company_name", "type": "string"},
        # Note: type of the items can be a previously defined complex type
        {"name": "employees", "type": {"type": "array", "items": person_schema}}
    ]
}


# Writing data to an Avro file using the defined schemas
def write_avro_file(file_path, avro_schema, data):
    writer_schema = avro.schema.parse(json.dumps(avro_schema))
    with open(file_path, 'wb') as avro_file, \
            DataFileWriter(avro_file, DatumWriter(), writer_schema) as writer:
        writer.append(data)


# Reading data from an Avro file
def read_avro_file(file_path):
    with open(file_path, 'rb') as avro_file, \
            DataFileReader(avro_file, DatumReader()) as reader:
        records = [record for record in reader]
        return records


if __name__ == "__main__":
    # A simple example
    # simple_value = "a string value"
    # write_avro_file("simple.avro", simple_value, simple_schema)
    # print(read_avro_file("simple.avro"))

    # Sample data to be written to the Avro file
    person_alice = {"name": "Alice", "age": 30,
                    "emails": ["alice@example.com", "alice@work.com"],
                    "position": "MANAGER",
                    "tags": {"motivation": "medium", "seniority_level": "senior"}}

    person_peter = {"name": "Peter",
                    "emails": ["peter@example.com"],
                    "position": "CLERK",
                    "tags": {"motivation": "high", "seniority_level": "medior"}}

    person_sarah = {"name": "Sarah"}  # TODO: try adding this person to the list of employees
    company_data = {"company_name": "XYZ Corp", "employees": [person_alice, person_peter]}

    # Write data to an Avro file
    write_avro_file("company.avro", company_schema, company_data)

    # Read data from the Avro file
    # Note: Reading does not require a schema (as it is embedded into the avro file)
    pprint(read_avro_file("company.avro"))
