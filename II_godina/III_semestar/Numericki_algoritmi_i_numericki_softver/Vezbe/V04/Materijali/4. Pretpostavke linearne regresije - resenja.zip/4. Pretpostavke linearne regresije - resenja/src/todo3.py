import seaborn as sb
import pandas as pd
from sklearn.linear_model import LinearRegression    
sb.set(font_scale=1.)
import warnings
warnings.filterwarnings("ignore")

import line_pretpostavke as line


if __name__ == '__main__':
    pass