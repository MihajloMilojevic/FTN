import pandas as pd
import statsmodels.api as sm
from sklearn.model_selection import train_test_split

from todo1 import are_assumptions_satisfied
from todo2 import fit_and_get_rsquared_adj_test, get_rsquared_adj

if __name__ == '__main__':
    pass