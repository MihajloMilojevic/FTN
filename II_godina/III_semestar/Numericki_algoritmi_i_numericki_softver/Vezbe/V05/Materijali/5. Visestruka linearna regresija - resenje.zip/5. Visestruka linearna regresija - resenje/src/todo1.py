import pandas as pd
import statsmodels.api as sm
from sklearn.model_selection import train_test_split

import line_pretpostavke as line

def are_assumptions_satisfied(model, x, y, p_value_thresh=0.01):
    '''provera pretpostavki.'''
    pass


if __name__ == '__main__':
    pass