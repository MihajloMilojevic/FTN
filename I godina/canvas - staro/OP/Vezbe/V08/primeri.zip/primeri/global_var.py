a = "ABC"


def f():
    a = 11
    print(a)


def main():
    f()
