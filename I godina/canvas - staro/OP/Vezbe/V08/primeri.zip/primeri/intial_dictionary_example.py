if __name__ == '__main__':
    data_list = [[1, "Aca"], [2, "Jovana"], [3, "Ivana"]]

    dictionary = {}

    for id, name in data_list:
        user = {"id": id, "name": name}
        if id not in dictionary:
            dictionary[id] = user

    for id, user in dictionary.items():
        if user["name"] == "Ivana":
            print("%d %s" % (user["id"], user["name"]))














