def easter(year):
    a=year%19
    b=year%4
    c=year%7
    d=(19*a+24)%30
    e=(2*b+4*c+6*d+5)%7

    date = 22+d+e
    if year in [1954, 1981, 2049, 2076]:
        date -= 7

    print(date)
    if 0<date<=31:
        print("Datum je", date, "mart.")
        return
    elif date<61:
        print("Datum je", date-31, "april.")
        return
    else:
        print("Datum je", date-61, "maj.")

if __name__ == '__main__':
    easter(1954)

