def main():
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    print(collection[1:])
    print(collection[3:7:2])

    # new_coll = []
    # for i in range(len(collection)):
    #     new_coll[i] = collection[i]

    new_coll = []
    for elem in collection:
        new_coll.append(elem)

    new_coll.append(['a', 'b', 'c'])
    print(new_coll)

    new_coll = [0] * len(collection)
    print(new_coll)

    for i in range(len(collection)): #[0,1,2,3,4,5,6,7,8]
        #i += 2
        new_coll[i] = collection[i]

    for i, elem in enumerate(collection):
        print("Na indeksu", i, "se nalazi element", elem)

    skip_collection = ["Pera", "Jovana", "Sima", "Aleksandra", "Sima"]

    for name in skip_collection:
        if name == "Sima":
            print(name)
            break
    else:
        print("Nema korisnika.")


if __name__ == '__main__':
    main()
