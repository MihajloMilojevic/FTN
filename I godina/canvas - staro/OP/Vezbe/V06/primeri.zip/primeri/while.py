if __name__ == '__main__':

    answer = 4
    while True:
        print("Opcija 1")
        print("Opcija 2")
        print("Opcija 3")
        print("x za izlaz")

        answer = input("Odaberite jednu od opcija: ")

        if answer == "1":
            print("Odabrali ste opciju 1")
        elif answer == "2":
            print("Odabrali ste opciju 2")
        elif answer == "3":
            print("Odabrali ste opciju 3")
        elif answer == "x":
            print("Doviđenja!")
            break
        else:
            print("Pogrešan unos.")
