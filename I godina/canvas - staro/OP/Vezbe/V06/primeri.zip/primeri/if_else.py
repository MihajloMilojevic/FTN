if __name__ == '__main__':
    niz = [1, 2, ""]

    if len(niz) > 2:
        treci = niz[2]
        if treci:
            print()