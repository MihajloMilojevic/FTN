def square(x):
    return x*x

a = 3
b = 4
c = 5
print square(a) + square(b) == square(c)

