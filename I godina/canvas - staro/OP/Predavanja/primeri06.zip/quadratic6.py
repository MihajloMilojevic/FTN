# quadratic6.py
import math 

def main():
    print "Izracunavanje realnih korena kvadratne jednacine\n"

    try:
        a, b, c = eval(raw_input("Unesite koeficijente (a, b, c): "))
        discRoot = math.sqrt(b * b - 4 * a * c)
        root1 = (-b + discRoot) / (2 * a)
        root2 = (-b - discRoot) / (2 * a)
        print "\nResenja su:", root1, root2
    except ValueError as excObj:
        if str(excObj) == "math domain error":
            print "Nema realnih korena!"
        else:
            print "Pogresan broj koeficijenata."
    except NameError:
        print "Niste uneli tri broja."
    except TypeError:
        print "Na ulazu nisu sve brojevi."
    except SyntaxError:
        print "Unos je neispravan. Nedostaje zarez?"
    except:
        print "Nesto nije u redu!"

main()
