# convert2.py
# Konvertuje Celzijuse u Farenhajte
# Ispisuje upozorenja za hladno i toplo vreme

def main():
    celsius = eval(raw_input("Unesite temperaturu u C >> "))
    fahrenheit = 9/5 * celsius + 32
    print "Temperatura je", fahrenheit, "stepeni Farenhajta."

    # Ispisi upozorenja za ekstremne temperature
    if fahrenheit > 90:
        print "Bas je vrucina!"
    if fahrenheit < 30:
        print "Brrrrr. Dobro se obuci!"

main()
