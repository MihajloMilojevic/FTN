# quadratic3.py
import math

def main():
    print "Izracunavanje realnih korena kvadratne jednacine\n"
    a, b, c = eval(raw_input("Unesite koeficijente (a, b, c): "))

    discrim = b * b - 4 * a * c
    if discrim < 0:
        print "\nJednacina nema realne korene!"
    else:
        discRoot = math.sqrt(b * b - 4 * a * c)
        root1 = (-b + discRoot) / (2 * a)
        root2 = (-b - discRoot) / (2 * a)
        print "\nResenja su:", root1, root2
main()
